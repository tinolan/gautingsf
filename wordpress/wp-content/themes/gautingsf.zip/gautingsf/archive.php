<?php
/* Template Name: Custom Template */
get_header();
?>
    <main id="main" class="content-wrapper">
        <?php wp_list_pages() ?>
        
    </main><!-- #main -->
<?php
get_footer();