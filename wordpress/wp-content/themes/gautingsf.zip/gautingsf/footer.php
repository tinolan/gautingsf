<footer>
    <div id="footer_content">
        <div id="footer_title">
            <h3>Gauting Schwimmbad Förderverein</h3>
        </div>  
        <?php wp_nav_menu( array('theme_location' => 'footer-menu') ); ?>
    </div>
    <div id="design">Design by Valentin Langer</div>

    
</footer>

</body>
</html>